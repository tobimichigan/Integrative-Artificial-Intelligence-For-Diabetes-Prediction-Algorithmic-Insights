# ===== requirements.txt =====
# Save the following block as `requirements.txt` in your project root.
# You can install them with: pip install -r requirements.txt

pandas>=1.3
numpy>=1.21
scikit-learn>=1.0
matplotlib>=3.4
seaborn>=0.11
torch>=1.10
tqdm>=4.60

# ===== inference.py =====
# Standalone inference script that loads saved sklearn Pipeline models
# and generates a submission CSV. Save this block as `inference.py`.

"""
Usage examples:

# Basic usage (defaults):
python inference.py --test_csv /path/to/test.csv

# Specify output filename and model prefix (if you used a different prefix when saving):
python inference.py --test_csv /path/to/test.csv --models_dir models --model_prefix model --output submission_from_saved_models.csv

Notes:
- This script expects two pickled sklearn Pipeline objects to exist:
  models/{model_prefix}_item_model.pkl
  models/{model_prefix}_qty_model.pkl
  (These are the files created by the pipeline's `save_models` function.)
- The script implements a conservative cleaning/feature-engineering routine similar to the training pipeline so the test DataFrame matches the model expectations.
"""

import argparse
import os
import sys
import pickle
import pandas as pd
import numpy as np
from datetime import datetime


def load_models(models_dir='models', model_prefix='model'):
    item_model_path = os.path.join(models_dir, f"{model_prefix}_item_model.pkl")
    qty_model_path = os.path.join(models_dir, f"{model_prefix}_qty_model.pkl")

    if not os.path.exists(item_model_path) or not os.path.exists(qty_model_path):
        raise FileNotFoundError(f"Model files not found in {models_dir} with prefix {model_prefix}. Expected:\n"
                                f"{item_model_path}\n{qty_model_path}")

    with open(item_model_path, 'rb') as f:
        item_model = pickle.load(f)

    with open(qty_model_path, 'rb') as f:
        qty_model = pickle.load(f)

    print(f"Loaded models: {item_model_path}, {qty_model_path}")
    return item_model, qty_model


def simple_clean_test_df(df):
    """
    Minimal cleaning of the test dataframe to mimic the training pipeline's cleaning.
    - Drops 'MW' if present
    - Cleans monetary columns with $ and commas
    - Extracts date parts for invoiceDate, CONSTRUCTION_START_DATE, SUBSTANTIAL_COMPLETION_DATE
    """
    df = df.copy()

    # Drop MW if present
    if 'MW' in df.columns:
        df.drop(columns=['MW'], inplace=True)

    # Convert string-based numeric columns to proper numbers
    for col in ['invoiceTotal', 'QtyShipped', 'UnitPrice', 'ExtendedPrice', 'ExtendedQuantity']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col].astype(str).str.replace(r'[$,]', '', regex=True), errors='coerce')

    # Handle date columns and create *_day, *_month, *_year
    for col in ['invoiceDate', 'CONSTRUCTION_START_DATE', 'SUBSTANTIAL_COMPLETION_DATE']:
        if col in df.columns:
            parsed = pd.to_datetime(df[col], errors='coerce')
            df[f'{col}_day'] = parsed.dt.day
            df[f'{col}_month'] = parsed.dt.month
            df[f'{col}_year'] = parsed.dt.year

    # Drop original date columns
    df.drop(columns=['invoiceDate', 'CONSTRUCTION_START_DATE', 'SUBSTANTIAL_COMPLETION_DATE'], inplace=True, errors='ignore')

    return df


def create_features_for_inference(df):
    """
    Minimal feature engineering used by the training pipeline. This mirrors the `create_features` in the training script,
    but is defensive and will skip missing columns.
    """
    df = df.copy()

    # project_duration_days (requires both date parts to exist)
    try:
        start = pd.to_datetime(df['CONSTRUCTION_START_DATE_year'].astype(str).fillna('') + '-' +
                               df['CONSTRUCTION_START_DATE_month'].astype(str).fillna('') + '-' +
                               df['CONSTRUCTION_START_DATE_day'].astype(str).fillna(''), errors='coerce')

        end = pd.to_datetime(df['SUBSTANTIAL_COMPLETION_DATE_year'].astype(str).fillna('') + '-' +
                             df['SUBSTANTIAL_COMPLETION_DATE_month'].astype(str).fillna('') + '-' +
                             df['SUBSTANTIAL_COMPLETION_DATE_day'].astype(str).fillna(''), errors='coerce')

        df['project_duration_days'] = (end - start).dt.days
    except Exception:
        df['project_duration_days'] = np.nan

    # price_per_sqft = invoiceTotal / SIZE_BUILDINGSIZE
    if 'invoiceTotal' in df.columns and 'SIZE_BUILDINGSIZE' in df.columns:
        # Guard against 0 and missing
        df['price_per_sqft'] = df.apply(
            lambda row: (row['invoiceTotal'] / row['SIZE_BUILDINGSIZE']) if pd.notna(row['invoiceTotal']) and pd.notna(row['SIZE_BUILDINGSIZE']) and row['SIZE_BUILDINGSIZE'] > 0 else 0,
            axis=1
        )
    else:
        df['price_per_sqft'] = 0

    # log transforms
    for col in ['SIZE_BUILDINGSIZE', 'invoiceTotal', 'ExtendedPrice']:
        if col in df.columns:
            try:
                df[f'log_{col}'] = np.log1p(df[col].clip(lower=0).fillna(0))
            except Exception:
                df[f'log_{col}'] = 0
        else:
            df[f'log_{col}'] = 0

    return df


def run_inference(test_csv, models_dir='models', model_prefix='model', output='submission.csv'):
    # Load models
    item_model, qty_model = load_models(models_dir=models_dir, model_prefix=model_prefix)

    # Read test csv
    print(f"Reading test CSV: {test_csv}")
    test_df = pd.read_csv(test_csv)

    # Keep original copy for id column
    if 'id' not in test_df.columns:
        raise KeyError("The test CSV must contain an 'id' column used for the submission file.")

    original_test_df = test_df.copy()

    # Clean and feature engineer
    test_cleaned = simple_clean_test_df(test_df)
    test_engineered = create_features_for_inference(test_cleaned)

    # Some saved pipelines expect the exact set of columns used in training; since we don't have the full training
    # environment in this standalone script we will attempt to pass the engineered dataframe directly to the
    # loaded sklearn Pipeline objects. The saved pipelines (if created using the training script) already include
    # a preprocessor inside the Pipeline so raw dataframe columns should be accepted.

    # Make predictions
    print("Generating predictions...")
    try:
        item_preds = item_model.predict(test_engineered)
        qty_preds = qty_model.predict(test_engineered)
    except Exception as e:
        print("Error during model prediction. This usually means the model expects different columns than provided.")
        raise

    # Create submission DataFrame
    submission_df = pd.DataFrame({
        'id': original_test_df['id'],
        'MasterItemNo': item_preds,
        'QtyShipped': qty_preds
    })

    # Ensure numeric types where applicable
    submission_df['MasterItemNo'] = pd.to_numeric(submission_df['MasterItemNo'], errors='coerce')
    submission_df['QtyShipped'] = pd.to_numeric(submission_df['QtyShipped'], errors='coerce')

    submission_df.to_csv(output, index=False)
    print(f"Saved submission file to: {output}")
    print(f"Submission preview (first 5 rows):\n{submission_df.head()}" )


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Inference script to load saved models and produce a submission CSV')
    parser.add_argument('--test_csv', type=str, required=True, help='Path to the test CSV file')
    parser.add_argument('--models_dir', type=str, default='models', help='Directory where the pickled models are stored')
    parser.add_argument('--model_prefix', type=str, default='model', help='Prefix used when saving models (default: model)')
    parser.add_argument('--output', type=str, default='submission.csv', help='Filename for the generated submission')

    args = parser.parse_args()

    run_inference(args.test_csv, models_dir=args.models_dir, model_prefix=args.model_prefix, output=args.output)
