# README — ML Pipeline for Item Classification & Quantity Forecasting

**Repository overview**

This repository contains a complete end-to-end machine learning pipeline implemented in a single Python script. The pipeline performs data loading, cleaning, feature engineering, exploratory data analysis (EDA), model training (an ensemble hybrid with a RandomForest classifier for item classification and GradientBoosting regressor for quantity forecasting), evaluation (rich visualizations), and model persistence for reuse.

The main entry point is the `run_complete_pipeline(train_file, test_file)` function and a `__main__` example at the bottom of the file.

---

## Table of Contents

1. [Quick summary](#quick-summary)
2. [Requirements](#requirements)
3. [Installation](#installation)
4. [How the code is organized](#how-the-code-is-organized)
5. [Data format and expected columns](#data-format-and-expected-columns)
6. [Quick start — run the entire pipeline](#quick-start---run-the-entire-pipeline)
7. [Run only training / run only inference (load & predict)](#run-only-training--run-only-inference-load--predict)
8. [Individual functions — what they do](#individual-functions---what-they-do)
9. [Outputs and artifacts created](#outputs-and-artifacts-created)
10. [Troubleshooting & tips](#troubleshooting--tips)
11. [Performance tuning & scaling suggestions](#performance-tuning--scaling-suggestions)
12. [Known limitations & TODOs](#known-limitations--todos)
13. [License & contact](#license--contact)

---

## Quick summary

- Trains a classification model to predict `MasterItemNo` and a regression model to predict `QtyShipped`.
- Produces EDA visuals, learning curves, confusion matrices, regression diagnostic plots, a `submission.csv`, and pickled model artifacts under `models/`.
- Main training uses `RandomForestClassifier` (classification) and `GradientBoostingRegressor` (regression) wrapped inside `sklearn.Pipeline` objects.

---

## Requirements

Minimum recommended Python environment:

- Python 3.8+
- pandas
- numpy
- scikit-learn
- matplotlib
- seaborn
- torch (PyTorch) — used for the `SimpleCNN` model definition (not required for the scikit-learn ensemble pipeline but left available for extensions)
- tqdm
- pickle (built-in)

Example `requirements.txt` snippet you can use:

```
pandas
numpy
scikit-learn
matplotlib
seaborn
torch
tqdm
```

Install via:

```bash
pip install -r requirements.txt
```

---

## Installation

1. Clone or copy the repository to your machine.
2. Create a virtual environment (optional but recommended):

```bash
python -m venv venv
source venv/bin/activate  # Linux / macOS
venv\Scripts\activate     # Windows
```

3. Install requirements (see section above).

4. Place your `train.csv` and `test.csv` into a known folder; update the paths in the `__main__` block or call the pipeline directly from your script or interactive session.

---

## How the code is organized

The script is organized into logical sections (and functions):

1. **Data loading & preparation** — `load_and_prepare_data`
2. **EDA** — `perform_comprehensive_eda`
3. **Feature engineering** — `create_features`
4. **Splitting & evaluation setup** — `split_data`
5. **Preprocessing pipeline** — `get_preprocessor`
6. **Model building & training** — `create_ensemble_model`
7. **Learning curve and overfitting detection** — `plot_learning_curves`
8. **Outlier detection & weighting** — `detect_outliers_and_adjust_weights`
9. **Evaluation helpers & plotting** — `evaluate_model`, `plot_enhanced_classification_results`, `plot_enhanced_regression_results`
10. **Prediction & submission helpers** — `make_predictions`, `make_submission_file`, `preview_submission`
11. **Model persistence** — `save_models`, `load_models`
12. **End-to-end runner** — `run_complete_pipeline`


---

## Data format and expected columns

The code expects training and test CSVs that roughly contain the following columns (not all are required but are referenced in preprocessing & feature engineering):

- `id` (used at submission creation)
- `MasterItemNo` (target — categorical classification)
- `QtyShipped` (target — numerical regression)
- `invoiceTotal`, `UnitPrice`, `ExtendedPrice`, `ExtendedQuantity` (string numbers like `$1,234.00` are handled and converted to numeric)
- `invoiceDate`, `CONSTRUCTION_START_DATE`, `SUBSTANTIAL_COMPLETION_DATE` (date handling creates *_day, *_month, *_year features)
- `SIZE_BUILDINGSIZE` (used in feature engineering)

Notes:
- If your CSVs have different column names, either rename them before running or modify the script accordingly.
- Rows with missing targets (`MasterItemNo` or `QtyShipped`) are filtered out before training.
- The code will drop columns named `MW` if present.

---

## Quick start — run the entire pipeline

1. Save the script to a file (for example, `ml_pipeline.py`).
2. Edit the `__main__` section if necessary to point to your dataset paths. Example paths are present:

```python
train_file = "/kaggle/input/ctai-ctd-hackathon/train.csv"
test_file = "/kaggle/input/ctai-ctd-hackathon/test.csv"
```

3. Run the script from the command line:

```bash
python ml_pipeline.py
```

What happens:
- The pipeline loads + prepares data, runs EDA (saves plots in `plots/`), engineers features, splits the dataset (train/val/test), trains the ensemble models, generates evaluation plots, creates `submission.csv`, and saves model pickles in `models/`.

Expected directories after a successful run:

```
plots/           # many .png figures
models/          # model pickles like model_item_model.pkl, model_qty_model.pkl
submission.csv   # final predictions for the original test set
```

---

## Run only training / run only inference (load & predict)

If you already trained and saved models, you can skip training and perform predictions on new test data using the provided `load_models`, `create_features`, and `make_predictions` utilities.

Example Python snippet (run in a Python shell or separate script):

```python
import pandas as pd
from ml_pipeline import load_models, create_features, make_predictions, make_submission_file

# Load the original test csv (to get the 'id' column used in submission)
original_test = pd.read_csv("/path/to/test.csv")

# Load trained models
item_model, qty_model = load_models(filepath_prefix='model')  # adjust prefix if needed

# Prepare the test dataframe. The script's create_features expects the date fields' *_year/_month/_day to exist.
# If your saved preprocessing expects those features, create them before calling create_features. If you use the pipeline's
# load-and-prepare function, ensure it was applied prior to saving the test CSV used here.

test_df = pd.read_csv("/path/to/test.csv")
# Option: reuse load_and_prepare_data(train_path, test_path) to create consistent preprocessing in one step
# or recreate the same cleaned form used during training.

# Run feature engineering (this may require those derived date columns to already exist)
# If you used the full pipeline, you likely saved a preprocessor object — if so you should also use that preprocessor
# when calling model.predict. The pipeline objects saved by save_models include the preprocessor inside the Pipeline.

test_engineered = create_features(test_df)

# Make predictions (if the loaded models are sklearn Pipelines with the preprocessor, pass raw test dataframe directly)
item_preds, qty_preds = make_predictions(item_model, qty_model, test_engineered)

# Create submission
make_submission_file(original_test, item_preds, qty_preds, filepath="submission_from_saved_models.csv")
```

Important notes about inference:
- If you saved models using `save_models`, the saved pickles are full sklearn `Pipeline` objects that include the `preprocessor` step. That means you can pass the raw `DataFrame` with the same column names into `model.predict()` without manually calling `preprocessor.transform()`.
- If you only saved raw model objects (without preprocessor), you must apply the same preprocessing pipeline before calling `predict()`.

---

## Individual functions — what they do (short)

- `load_and_prepare_data(train_path, test_path)` — loads CSVs, concatenates, cleans, converts string numbers, extracts date parts, and returns cleaned train/test DataFrames.
- `perform_comprehensive_eda(df)` — saves a set of EDA charts into `plots/`.
- `create_features(df)` — generates engineered features like `project_duration_days`, `price_per_sqft`, and log transforms.
- `split_data(df, ...)` — filters rows with missing targets, removes rare classes (<2 samples), and splits into train/val/test with stratification on item labels.
- `get_preprocessor(df)` — builds a `ColumnTransformer` with numeric imputation+scaling and categorical imputation+one-hot encoding.
- `create_ensemble_model(preprocessor, X_train, y_qty_train, y_item_train)` — constructs sklearn Pipelines for classification and regression and fits them.
- `evaluate_model(...)` — computes `accuracy`, `f1`, `mae`, `reg_score`, and a composite `final_score`.
- `plot_learning_curves(...)` — plots learning curves and annotates potential overfitting.
- `detect_outliers_and_adjust_weights(df, target_col)` — returns sample weights using IQR-based outlier detection.
- `plot_enhanced_classification_results(...)`, `plot_enhanced_regression_results(...)` — produce diagnostic plots saved under `plots/`.
- `make_predictions(item_model, qty_model, X_test)` — convenience wrapper to `predict()` on both models.
- `make_submission_file()` & `preview_submission()` — create and preview `submission.csv`.
- `save_models(...)` and `load_models(...)` — pickle/unpickle models and preprocessor.

---

## Outputs and artifacts created

- `plots/` — EDA, learning curves, confusion matrix visuals, regression diagnostics (PNG files).
- `models/` — `model_item_model.pkl` and `model_qty_model.pkl` (pickled sklearn Pipeline objects).
- `submission.csv` — submission file containing `id`, `MasterItemNo`, and `QtyShipped`.
- `console logs` — descriptive print statements on progress and sizes.

---

## Troubleshooting & tips

- **FileNotFoundError**: confirm the `train_file` and `test_file` paths are correct.
- **Empty dataset after filtering**: The pipeline filters rows where either target is missing. If many rows lack `QtyShipped` or `MasterItemNo`, you will lose samples. Consider imputing or adjusting the filter logic.
- **Rare classes**: The script removes classes with only a single sample to allow stratified splits. If your dataset is extremely imbalanced, consider alternative sampling strategies (stratified K-fold, upsampling, class-weights).
- **Memory issues**: For very large datasets, use `dtype` memory optimizations, process the data in chunks, or train on a machine with more RAM. Consider reducing `n_estimators` or using more memory-efficient models.
- **Torch is defined but unused for training currently**: The `SimpleCNN` class exists for extensions. The current main pipeline uses sklearn models.

---

## Performance tuning & scaling suggestions

- Try `n_estimators`, `max_depth`, and learning rate tuning for GradientBoosting. Use `GridSearchCV` or `RandomizedSearchCV`.
- If training time is long, try `HistGradientBoostingRegressor` (faster on large datasets) or `LightGBM`/`XGBoost` (external libs).
- To speed up one-hot encoding on high-cardinality categorical features, consider `TargetEncoding`, hashing, or embedding approaches.

---

## Known limitations & TODOs

- The script drops original date columns after extracting day/month/year — if you need full timestamps or other date-derived features, extend `clean_data`.
- There is limited handling for extremely high-cardinality categorical fields — you may need encoding/embedding modifications.
- The `SimpleCNN` model is defined but not integrated into the ensemble. Consider adding a PyTorch-based branch for sequence / embedding inputs.
- No unit tests included — consider adding pytest-based tests for key functions.

---

## License & contact

This README and the accompanying code are provided as-is. You may reuse and adapt the code for your purposes. If you'd like help customizing the pipeline (adding GPU training, LightGBM, or multi-output models), open an issue or message the repository maintainer.



